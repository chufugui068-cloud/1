---
name: Model request
about: Request support for a new model to be added to Ollama
labels: model request
---