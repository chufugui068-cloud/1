# Webview

This is a vendored version of the [webview_go](https://github.com/webview/webview_go) project

`WebView2.h` is a vendored version of the Microsoft's [WebView2](https://learn.microsoft.com/en-us/microsoft-edge/webview2/get-started/win32)
