//go:build windows

package cmd

const defaultEditor = "edit"
